package com.laraib.emsystem.repository;

import com.laraib.emsystem.model.Department;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // Custom query using @Query annotation
    @Query("SELECT d FROM Department d WHERE d.name = ?1")
    Department findByName(String name);


    //using named query
    @Query(name = "Department.findByName")
    Department findDepartmentByName(String name);
}
