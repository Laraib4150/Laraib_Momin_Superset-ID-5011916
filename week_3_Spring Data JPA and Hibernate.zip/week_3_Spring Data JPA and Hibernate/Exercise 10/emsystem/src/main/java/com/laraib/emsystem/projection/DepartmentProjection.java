package com.laraib.emsystem.projection;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
