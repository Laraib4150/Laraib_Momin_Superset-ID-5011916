package com.lara.emsystem.repository;

import com.lara.emsystem.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    // Custom query method to find employees by name
    @Query("SELECT e FROM Employee e WHERE e.name LIKE %?1%")
    List<Employee> findByName(String name);

    // Custom query method to find employees by department id
    @Query("SELECT e FROM Employee e WHERE e.department.id = ?1")
    List<Employee> findByDepartmentId(Long departmentId);

    // use named queries
    @Query(name = "Employee.findByName")
    List<Employee> findEmployeesByName(String name);

    @Query(name = "Employee.findByDepartmentId")
    List<Employee> findEmployeesByDepartmentId(Long departmentId);

    // Pagination and sorting
    Page<Employee> findByName(String name, Pageable pageable);
    Page<Employee> findByDepartmentId(Long departmentId, Pageable pageable);
}
