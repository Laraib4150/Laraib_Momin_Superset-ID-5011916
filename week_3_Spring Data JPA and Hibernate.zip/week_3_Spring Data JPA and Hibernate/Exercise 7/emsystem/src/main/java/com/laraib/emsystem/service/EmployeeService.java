package com.lara.emsystem.service;

import com.lara.emsystem.model.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    Employee saveEmployee(Employee employee);
    List<Employee> getAllEmployees();
    Optional<Employee> getEmployeeById(Long id);
    void deleteEmployee(Long id);
    List<Employee> getEmployeesByName(String name);
    List<Employee> getEmployeesByDepartmentId(Long departmentId);

    Page<Employee> getAllEmployees(Pageable pageable);
    Page<Employee> getEmployeesByName(String name, Pageable pageable);
    Page<Employee> getEmployeesByDepartmentId(Long departmentId, Pageable pageable);
}
