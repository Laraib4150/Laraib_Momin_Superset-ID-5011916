package com.laraib.emsystem.service;

import com.laraib.emsystem.model.Department;
import java.util.List;
import java.util.Optional;

public interface DepartmentService {
    Department saveDepartment(Department department);
    List<Department> getAllDepartments();
    Optional<Department> getDepartmentById(Long id);
    void deleteDepartment(Long id);
    Department getDepartmentByName(String name);
}
