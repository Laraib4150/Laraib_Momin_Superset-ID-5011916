package com.lara.emsystem.service;

import com.lara.emsystem.model.Department;
import java.util.List;
import java.util.Optional;

public interface DepartmentService {
    Department saveDepartment(Department department);
    List<Department> getAllDepartments();
    Optional<Department> getDepartmentById(Long id);
    void deleteDepartment(Long id);
    Department getDepartmentByName(String name);
}
